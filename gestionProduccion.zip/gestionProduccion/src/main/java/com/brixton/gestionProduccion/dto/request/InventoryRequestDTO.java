package com.brixton.gestionProduccion.dto.request;

import lombok.Getter;
import lombok.ToString;

@Getter

@ToString
public class InventoryRequestDTO {
    private int id;
    private int quantity;
}
