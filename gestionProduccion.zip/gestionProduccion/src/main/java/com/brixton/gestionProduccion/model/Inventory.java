package com.brixton.gestionProduccion.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class Inventory {
    private int id;
    private int quantity;
}
