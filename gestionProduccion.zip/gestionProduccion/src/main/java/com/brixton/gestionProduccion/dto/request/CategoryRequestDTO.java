package com.brixton.gestionProduccion.dto.request;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter

@ToString
public class CategoryRequestDTO {
    private int id;
    private String name;
    //private List<Product> productList;
}
